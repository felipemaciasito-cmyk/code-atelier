# Code Atelier — bibliothèque complète

Application web responsive qui embarque la totalité des fichiers du dépôt fourni dans `sololearn-main/`, plus un catalogue consultable dans `app-data.js`.

## Démarrer
Ouvrir `index.html` dans un navigateur. Le catalogue est embarqué dans `app-data.js`, ce qui permet de démarrer par double-clic sans serveur local.

## Fonctions
- Recherche par nom, chemin et contenu textuel
- Filtres : cours, pratiques, projets, Code Coaches, documentation, autres ressources
- Consultation intégrée des fichiers texte, code et Markdown
- Téléchargement des fichiers
- Favoris conservés localement dans le navigateur
- Fichiers originaux inclus dans `sololearn-main/`

## Licence / attribution
Le fichier `sololearn-main/LICENSE` original est conservé. Le dépôt contient une licence MIT indiquant le copyright HenestrosaConH (2023). Garder le fichier de licence et les mentions associées lors de toute redistribution. La présence de cette licence ne tranche pas automatiquement les droits d’éventuels contenus tiers inclus dans le dépôt. Cette interface est indépendante et non officielle.

Source : https://github.com/HenestrosaDev/sololearn
