print("Python is fun")
