print(("ni" * 3) + '!')
